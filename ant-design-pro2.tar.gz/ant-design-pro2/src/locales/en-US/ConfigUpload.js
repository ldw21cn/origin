export default {
  'navbar.lang': '中文',
  'menu.home': 'Home',
  'menu.configmanage': 'ConfigManage',
  'menu.configmanage.configupload': 'ConfigUpload',
}
