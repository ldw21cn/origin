export default {
  'app.editor.flow.title': '流程圖編輯器',
  'app.editor.flow.description': '千言萬語不如一張圖，流程圖是表示算法思路的好方法',
  'app.editor.koni.title': '拓撲編輯器',
  'app.editor.koni.description': '拓撲結構圖是指由網絡節點設備和通信介質構成的網絡結構圖',
  'app.editor.mind.title': '腦圖編輯器',
  'app.editor.mind.description':
    '腦圖是表達發散性思維的有效圖形思維工具 ，它簡單卻又很有效，是一種實用性的思維工具',
};
