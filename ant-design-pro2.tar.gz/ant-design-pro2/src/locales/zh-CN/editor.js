export default {
  'app.editor.flow.title': '流程图编辑器',
  'app.editor.flow.description': '千言万语不如一张图，流程图是表示算法思路的好方法',
  'app.editor.koni.title': '拓扑编辑器',
  'app.editor.koni.description': '拓扑结构图是指由网络节点设备和通信介质构成的网络结构图',
  'app.editor.mind.title': '脑图编辑器',
  'app.editor.mind.description':
    '脑图是表达发散性思维的有效图形思维工具 ，它简单却又很有效，是一种实用性的思维工具。',
};
