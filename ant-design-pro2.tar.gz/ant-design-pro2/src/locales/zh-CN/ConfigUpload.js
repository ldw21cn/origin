export default {
  'navbar.lang': 'English',
  'menu.home': '首页',
  'menu.configmanage': '配置管理',
  'menu.configmanage.configupload': '配置上传',

}
