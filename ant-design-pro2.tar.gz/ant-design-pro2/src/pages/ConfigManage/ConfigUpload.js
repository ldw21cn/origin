/* eslint-disable react/prefer-stateless-function */
import React, { PureComponent } from 'react';


export default class ConfigUpload extends PureComponent {

  render() {
    return (
      <div>
        HelloWorld
      </div>
    );
  }
}
