import dva from 'dva';
import createLoading from 'dva-loading';

const runtimeDva = window.g_plugins.mergeConfig('dva');
let app = dva({
  history: window.g_history,
  
  ...(runtimeDva.config || {}),
});

window.g_app = app;
app.use(createLoading());
(runtimeDva.plugins || []).forEach(plugin => {
  app.use(plugin);
});

app.model({ namespace: 'global', ...(require('/Users/lvdawei/ant-design-pro2/src/models/global.js').default) });
app.model({ namespace: 'list', ...(require('/Users/lvdawei/ant-design-pro2/src/models/list.js').default) });
app.model({ namespace: 'login', ...(require('/Users/lvdawei/ant-design-pro2/src/models/login.js').default) });
app.model({ namespace: 'menu', ...(require('/Users/lvdawei/ant-design-pro2/src/models/menu.js').default) });
app.model({ namespace: 'project', ...(require('/Users/lvdawei/ant-design-pro2/src/models/project.js').default) });
app.model({ namespace: 'setting', ...(require('/Users/lvdawei/ant-design-pro2/src/models/setting.js').default) });
app.model({ namespace: 'user', ...(require('/Users/lvdawei/ant-design-pro2/src/models/user.js').default) });
