import FlowDetailPanel from './FlowDetailPanel';

export default FlowDetailPanel;
