import FlowDetailPanel from './FlowDetailPanel';
import MindDetailPanel from './MindDetailPanel';
import KoniDetailPanel from './KoniDetailPanel';

export { FlowDetailPanel, MindDetailPanel, KoniDetailPanel };
