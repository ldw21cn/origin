import React from 'react';

export interface SelectLangProps {
  className?: string;
}

export default class SelectLang extends React.Component<SelectLangProps, any> {}
