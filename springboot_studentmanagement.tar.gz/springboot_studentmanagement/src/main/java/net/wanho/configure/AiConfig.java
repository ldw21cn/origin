package net.wanho.configure;


import org.springframework.web.servlet.mvc.SimpleControllerHandlerAdapter;

import java.util.ArrayList;

/**
 * @Author lvdawei
 * @Date 2019/4/14 22:46
 * @Version 1.0
 */
public class AiConfig {

    private AiConfig aiConfig=null;

    public void test() {
        ArrayList<Object> list = new ArrayList<Object>();
        list.add("");

    }

}
