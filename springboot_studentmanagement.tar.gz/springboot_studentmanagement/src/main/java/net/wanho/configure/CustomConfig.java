package net.wanho.configure;


import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * @Author lvdawei
 * @Date 2019/4/14 13:00
 * @Version 1.0
 */
@Configuration
public class CustomConfig implements InitializingBean {
    private static CustomConfig adminConfig = null;

    public static CustomConfig getAdminConfig() {
        return  adminConfig;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        adminConfig = this;
    }

    @Value("${custom.config.mailHost}")
    private String mailHost;

    @Value("${custom.config.mailPort}")
    private String mailPort;


    public String getMailHost() {
        return mailHost;
    }

    public void setMailHost(String mailHost) {
        this.mailHost = mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public void setMailPort(String mailPort) {
        this.mailPort = mailPort;
    }

    @Override
    public String toString() {
        return "CustomConfig{" +
                "mailHost='" + mailHost + '\'' +
                ", mailPort='" + mailPort + '\'' +
                '}';
    }
}
