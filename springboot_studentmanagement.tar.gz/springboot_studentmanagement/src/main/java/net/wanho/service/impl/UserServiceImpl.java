package net.wanho.service.impl;


import net.wanho.mapper.UserMapper;
import net.wanho.model.User;
import net.wanho.service.UserServiceI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/1 16:06
 * @Version 1.0
 */
@Service("userService")
public class UserServiceImpl implements UserServiceI {

    @Autowired
    private UserMapper userMapper;

    @Override
    public List<User> getCurrentUser() {
        return userMapper.getCurrentUser();
    }
}
