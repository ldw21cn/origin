package net.wanho.service;


import net.wanho.model.User;

import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/1 16:05
 * @Version 1.0
 */
public interface UserServiceI {
    List<User> getCurrentUser();

}
