package net.wanho.service;


import net.wanho.model.TmDto;

import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/10 13:13
 * @Version 1.0
 */
public interface TmenuServiceI {

    List<TmDto> selectTmenus();

}
