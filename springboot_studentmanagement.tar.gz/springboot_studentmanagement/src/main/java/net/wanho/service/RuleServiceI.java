package net.wanho.service;


import com.github.pagehelper.PageInfo;
import net.wanho.model.Rule;

import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/2 09:40
 * @Version 1.0
 */
public interface RuleServiceI {

    List<Rule> getRules();

    PageInfo<Rule> getRules(Integer currentPage, Integer pageSize, Rule rule);

    void deleteRuleById(String id);

    void deleteRuleByIds(List<Integer> ids);

    void addRule(Rule rule);

    void updateRule(Rule rule);
}
