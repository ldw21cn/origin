package net.wanho.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import net.wanho.mapper.StudentMapper;
import net.wanho.model.Rule;
import net.wanho.model.Student;
import net.wanho.service.StudentServiceI;
import net.wanho.utils.PageConst;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by DUSTIN on 2019/1/14.
 */
@Service("studentService")
public class StudentServiceImpl implements StudentServiceI{
    @Autowired
    private StudentMapper studentMapper;

    @Override
    public PageInfo<Student> getAllStudents(Integer pageNo) {
        PageHelper.startPage(pageNo, PageConst.pageSize);
        List<Student> students = studentMapper.getAllStudents();
        PageInfo<Student> studentPageInfo = new PageInfo<Student>(students);
        return studentPageInfo;
    }

    @Override
    public List<Student> getAllStudents() {
        List<Student> allStudents = studentMapper.getAllStudents();
        return allStudents;
    }

    @Override
    public PageInfo<Student> getAllStudents(Integer _page, Integer _limit) {
        PageHelper.startPage(_page,_limit);
        List<Student> allStudents = studentMapper.getAllStudents();
        PageInfo<Student> pageInfo = new PageInfo<Student>(allStudents);
        return pageInfo;
    }

    @Override
    public void delStudentById(Integer id) {
        studentMapper.delStudentById(id);
    }
}
