package net.wanho.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import net.wanho.mapper.StudentMapper;
import net.wanho.model.Rule;
import net.wanho.model.Student;
import net.wanho.service.StudentServiceI;
import net.wanho.utils.PageConst;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created by DUSTIN on 2019/1/14.
 */
@Service("studentService")
@CacheConfig(cacheNames ="student",keyGenerator = "wiselyKeyGenerator",cacheManager = "cacheManager")
public class StudentServiceImpl implements StudentServiceI{
    @Autowired
    private StudentMapper studentMapper;

    @Override
    @Cacheable(sync = true)
    public PageInfo<Student> getAllStudents(Integer pageNo) {
        PageHelper.startPage(pageNo, 100000);
        List<Student> students = studentMapper.getAllStudents();
        PageInfo<Student> studentPageInfo = new PageInfo<Student>(students);
        return studentPageInfo;
    }

    @Override
    @Cacheable
    public PageInfo<Student> getAllStudents() {
        PageHelper.startPage(2, 100000);
        List<Student> allStudents = studentMapper.getAllStudents();
        PageInfo<Student> pageInfo = new PageInfo<Student>(allStudents);
        return pageInfo;
    }

    @Override
    public PageInfo<Student> getAllStudents(Integer _page, Integer _limit) {
        PageHelper.startPage(_page,_limit);
        List<Student> allStudents = studentMapper.getAllStudents();
        PageInfo<Student> pageInfo = new PageInfo<Student>(allStudents);
        return pageInfo;
    }

    @Override
    @Cacheable
    public Student getStudentById(Integer id) {
        Student student = studentMapper.getStudentById(id);
        return student;
    }

    @Override
    @CacheEvict(allEntries = true)
    public void delStudentById(Integer id) {
        studentMapper.delStudentById(id);
    }

    @Override
    @CachePut
    public void addStudent(Student student) {
        studentMapper.addStudent(student);
    }

    @Override
    @CachePut
    public void updateStudent(Student student) {
        studentMapper.updateStudent(student);
    }

    /**
     * 多线程插入数据库1000万条数据
     */
    @Override
    public void productionData() {

        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
                100,
                1000,
                30000,
                TimeUnit.SECONDS,
                new LinkedBlockingDeque<Runnable>(1000)
        );

        threadPoolExecutor.execute(
                new Runnable() {
                    @Override
                    public void run() {
                        for (int i = 1; i <= 10000; i++) {
                            studentMapper.addStudent(new Student(null, "张"+i,12));
                        }
                    }
                }
        );


        threadPoolExecutor.shutdown();

    }
}
