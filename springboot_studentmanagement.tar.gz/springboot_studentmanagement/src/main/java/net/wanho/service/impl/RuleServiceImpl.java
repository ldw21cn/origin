package net.wanho.service.impl;


import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import net.wanho.mapper.RuleMapper;
import net.wanho.model.Rule;
import net.wanho.redis.RedisCacheUtil;
import net.wanho.service.RuleServiceI;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/2 09:40
 * @Version 1.0
 */
@Service("ruleService")
public class RuleServiceImpl implements RuleServiceI {

    @Autowired
    private RuleMapper ruleMapper;

    @Autowired
    private RedisCacheUtil redisCacheUtil;

    @Autowired

    @Override
    public List<Rule> getRules() {
        List<Rule> rules = ruleMapper.getRules();
        return rules;
    }

    @Override
    public void updateRule(Rule rule) {
        ruleMapper.updateRule(rule);
    }

    @Override
    public PageInfo<Rule> getRules(Integer currentPage, Integer pageSize, Rule rule) {

       /* List list = redisCacheUtil.getCacheList("rules");
        if (CollectionUtils.isNotEmpty(list)) {
            int count = list.size();
            PageInfo<Rule> rulePageInfo = new PageInfo<>(list);
            rulePageInfo.setTotal(count);
            rulePageInfo.setPageSize(pageSize);
            rulePageInfo.setPageNum(currentPage);
            return rulePageInfo;
        }else {*/
            PageHelper.startPage(currentPage, pageSize);
            List<Rule> rules = ruleMapper.getRulesByCondition(rule);
            PageInfo<Rule> rulePageInfo = new PageInfo<Rule>(rules);
            return rulePageInfo;
    }

    @Override
    public void deleteRuleById(String id) {
        ruleMapper.deleteRuleById(id);
    }

    @Override
    public void deleteRuleByIds(List<Integer> ids) {
        ruleMapper.deleteRuleByIds(ids);
    }

    @Override
    public void addRule(Rule rule) {
        ruleMapper.addRule(rule);
    }
}
