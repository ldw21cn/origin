package net.wanho.service;

import com.github.pagehelper.PageInfo;
import net.wanho.model.Student;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by DUSTIN on 2019/1/14.
 */
public interface StudentServiceI {

    PageInfo<Student> getAllStudents();

    PageInfo<Student> getAllStudents(Integer pageNum);

    PageInfo<Student> getAllStudents(Integer _page,Integer _limit);

    void delStudentById(@Param("id") Integer id);

    Student getStudentById(Integer id);

    void addStudent(Student student);

    void updateStudent(Student student);

    void productionData();
}
