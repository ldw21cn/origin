package net.wanho.service.impl;


import net.wanho.mapper.TMenuMapper;
import net.wanho.model.TMenu;
import net.wanho.model.TmDto;
import net.wanho.service.TmenuServiceI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/10 13:15
 * @Version 1.0
 */
@Service("tmenuService")
public class TmenuServiceImpl implements TmenuServiceI {

    @Autowired
    private TMenuMapper tMenuMapper;

    @Override
    public List<TmDto> selectTmenus() {
        List<TmDto> tmenuDtos = tMenuMapper.selectTmenus();
        return tmenuDtos;
    }
}
