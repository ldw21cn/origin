package net.wanho.mapper;

import net.wanho.model.Student;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by DUSTIN on 2019/1/14.
 */
public interface StudentMapper {
    List<Student> getAllStudents();

    void delStudentById(@Param("id") Integer id);
}
