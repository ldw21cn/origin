package net.wanho.mapper;

import java.util.List;
import net.wanho.model.TMenu;
import net.wanho.model.TmDto;
import org.apache.ibatis.annotations.Param;

public interface TMenuMapper {
    List<TmDto> selectTmenus();

    List<TMenu> getMenuById(@Param("id") Integer id);
}