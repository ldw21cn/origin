package net.wanho.mapper;


import net.wanho.model.Rule;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/2 09:40
 * @Version 1.0
 */
public interface RuleMapper {
    List<Rule> getRules();

    List<Rule> getRulesByCondition(Rule rule);

    void deleteRuleById(@Param("id") String id);

    void deleteRuleByIds(List<Integer> ids);

    void addRule(Rule rule);

    void updateRule(Rule rule);
}
