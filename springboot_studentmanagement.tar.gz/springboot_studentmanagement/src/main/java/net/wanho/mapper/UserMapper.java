package net.wanho.mapper;


import net.wanho.model.User;

import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/1 16:04
 * @Version 1.0
 */
public interface UserMapper {
    List<User> getCurrentUser();
}
