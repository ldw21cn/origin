package net.wanho.controller;


import net.wanho.configure.CustomConfig;
import net.wanho.configure.JdbcConfig;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;


/**
 * @Author lvdawei
 * @Date 2019/4/5 16:02
 * @Version 1.0
 */
@RestController
@RequestMapping("/test")
public class LoggingTestController {
    private final Logger logger = LogManager.getLogger(this.getClass());

    @Autowired
    @Qualifier(value = "redisTemplate1")
    private RedisTemplate redisTemplate;


    @GetMapping("/hello")
    public String hello() {
        for(int i=0;i<100000;i++){
            logger.info("info execute index method");
            logger.warn("warn execute index method");
            logger.error("error execute index method");
        }
        return "My First SpringBoot Application";
    }

    @GetMapping("/config")
    public String getConfig() {
        CustomConfig adminConfig = CustomConfig.getAdminConfig();
        String mailPort = adminConfig.getMailPort();
        String mailHost = adminConfig.getMailHost();
        return "mailHost="+mailHost+",mailPort="+mailPort;
    }

    @GetMapping("/jdbc")
    public String getJdbcConfig() {
        JdbcConfig jdbcConfig = JdbcConfig.getJdbcConfig();
        String userName = jdbcConfig.getUserName();
        String url = jdbcConfig.getUrl();
        String driverClassName = jdbcConfig.getDriverClassName();
        String password = jdbcConfig.getPassword();
        return (userName+","+password+","+driverClassName+","+password);

    }

    @GetMapping("/redis")
    public String getRedis() {
        redisTemplate.opsForValue().set("name", "张三");
        Object name = redisTemplate.opsForValue().get("name");
        System.out.println(name.toString());
        return(name.toString());
    }





}
