package net.wanho.controller;


import net.wanho.service.StudentServiceI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @Author lvdawei
 * @Date 2019/4/17 09:15
 * @Version 1.0
 */
@Controller
@RequestMapping("/pdata")
public class GenerationData {

    @Autowired
    private StudentServiceI studentService;

    @GetMapping
    @ResponseBody
    public String generationData() {
        studentService.productionData();
        return "插入成功";
    }

}
