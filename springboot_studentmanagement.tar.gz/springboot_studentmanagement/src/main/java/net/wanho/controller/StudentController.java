package net.wanho.controller;

import com.github.pagehelper.PageInfo;
import net.wanho.model.Student;
import net.wanho.service.StudentServiceI;
import net.wanho.utils.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * Created by DUSTIN on 2019/1/14.
 */
@Controller
@RequestMapping("student")
public class StudentController {

    @Autowired
    private StudentServiceI studentService;


    @RequestMapping("/{pageNum}")
    @ResponseBody
    public JsonResult getStudents(@PathVariable Integer pageNum,HttpServletResponse response) {
        long start = System.currentTimeMillis();
        response.setHeader("Access-Control-Allow-Origin", "*");
        PageInfo<Student> pageInfo = studentService.getAllStudents(pageNum);
        JsonResult jsonResult = new JsonResult();
        jsonResult.setData(pageInfo.getList());
        long stop = System.currentTimeMillis();
        System.err.println("一共花费时间："+(stop - start)+"毫秒");
        return jsonResult;
    }

    @RequestMapping("/id/{id}")
    @ResponseBody
    public String getStudentById(@PathVariable Integer id) {
        Student student = studentService.getStudentById(id);
        return student+"";
    }


    @RequestMapping("/delete/{id}")
    public void deleteStudent(@PathVariable Integer id) {
        studentService.delStudentById(id);
    }

    @RequestMapping("/update")
    public void updateStudent() {
        Student student = new Student();
        student.setId(8);
        student.setName("lisi");
        student.setAge(22);
        studentService.updateStudent(student);
    }

    @RequestMapping("/add")
    public void addStudent() {
        Student student = new Student(null, "你", 22);
        studentService.addStudent(student);
    }

    @RequestMapping(value = "{id}",method = RequestMethod.POST)
    public void deleteStudentById(@PathVariable("id") Integer id,HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin", "*");
        studentService.delStudentById(id);
    }



    public String showAllStudents(@RequestParam(defaultValue = "1") Integer pageNo, Map map){
        PageInfo<Student> allStudents = studentService.getAllStudents(pageNo);
        map.put("students",allStudents.getList());
        map.put("totalPages",allStudents.getPages());
        map.put("currentPage",allStudents.getPageNum());
        return "students";
    }
}
