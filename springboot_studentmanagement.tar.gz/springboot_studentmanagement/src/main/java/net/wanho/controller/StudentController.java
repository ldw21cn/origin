package net.wanho.controller;

import com.github.pagehelper.PageInfo;
import net.wanho.model.Student;
import net.wanho.service.StudentServiceI;
import net.wanho.utils.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * Created by DUSTIN on 2019/1/14.
 */
@Controller
@RequestMapping("student")
public class StudentController {

    @Autowired
    private StudentServiceI studentService;


    @RequestMapping
    @ResponseBody
    public JsonResult getStudents(HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin", "*");
        List<Student> allStudents = studentService.getAllStudents();
        JsonResult jsonResult = new JsonResult();
        jsonResult.setData(allStudents);
        return jsonResult;

    }


    @RequestMapping(value = "{id}",method = RequestMethod.POST)
    public void deleteStudentById(@PathVariable("id") Integer id,HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin", "*");
        studentService.delStudentById(id);
    }



    public String showAllStudents(@RequestParam(defaultValue = "1") Integer pageNo, Map map){
        PageInfo<Student> allStudents = studentService.getAllStudents(pageNo);
        map.put("students",allStudents.getList());
        map.put("totalPages",allStudents.getPages());
        map.put("currentPage",allStudents.getPageNum());
        return "students";
    }
}
