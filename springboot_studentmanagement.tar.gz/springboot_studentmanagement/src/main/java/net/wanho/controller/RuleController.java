package net.wanho.controller;


import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import net.wanho.model.Rule;
import net.wanho.service.RuleServiceI;
import net.wanho.utils.HttpResult;
import net.wanho.utils.Pagination;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Author lvdawei
 * @Date 2019/4/2 09:22
 * @Version 1.0
 */
@Controller
@RequestMapping("rule")
//@CrossOrigin(origins = {"http://localhost:8000"})
public class RuleController {


    @Autowired
    private RuleServiceI ruleService;

    @GetMapping
    @ResponseBody
    public HttpResult getRule(@RequestParam(defaultValue = "1") Integer currentPage, @RequestParam(defaultValue = "10") Integer pageSize, Rule rule,HttpServletResponse response) {
//        response.addHeader("Access-Control-Allow-Origin","*");
        PageInfo<Rule> pageInfo = ruleService.getRules(currentPage, pageSize, rule);
        HttpResult jsonResult = new HttpResult();
        jsonResult.setList(pageInfo.getList());
        Pagination pagination = new Pagination();
        pagination.setTotal(pageInfo.getTotal());
        pagination.setCurrent(pageInfo.getPageNum());
        pagination.setPageSize(pageInfo.getPageSize());
        jsonResult.setPagination(pagination);
        return jsonResult;
    }


    @PostMapping
    public void updateRule(@RequestBody(required = true) Rule rule,HttpServletResponse response) {
        ruleService.updateRule(rule);
    }


    @PostMapping(value = "delete")
    public void deleteRule(@RequestBody(required = true) Map map, HttpServletResponse response) {
        List<Integer> ids = (List<Integer>) map.get("ids");
        ruleService.deleteRuleByIds(ids);
    }


    @PostMapping(value = "create")
    public void addRule(@RequestBody(required = true) Rule rule,HttpServletResponse response) {
        rule.setOwner("曲贡");
        rule.setStatus("2");
        rule.setCallNo(1460000);
        rule.setTitle("这是一个任务描述");
        rule.setCreatedAt(new Date());
        rule.setUpdatedAt(new Date());
        ruleService.addRule(rule);
    }

}
