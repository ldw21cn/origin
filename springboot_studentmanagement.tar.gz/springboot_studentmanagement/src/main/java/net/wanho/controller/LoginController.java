package net.wanho.controller;
import net.wanho.model.User;
import net.wanho.service.UserServiceI;
import net.wanho.utils.JsonResult;
import net.wanho.utils.UserResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * @Author lvdawei
 * @Date 2019/4/18 17:00
 * @Version 1.0
 */
@Controller
@RequestMapping("/api")
@CrossOrigin(value = "http://localhost:8000")
public class LoginController {

    @Autowired
    private UserServiceI userService;


    @GetMapping("/currentUser")
    @ResponseBody
    public String getCurrentUser() {
        return null;
    }

    @GetMapping("/users")
    @ResponseBody
    public String getUsers() {
        return null;
    }

    @PostMapping("/login/account")
    @ResponseBody
    public UserResult getAccount(@RequestBody Map map, HttpServletResponse response) {
        String userName = (String) map.get("userName");
        String password = (String) map.get("password");
        User user = userService.selectUserAndPassword(userName, password);
        if (null != user) {
            UserResult userResult = new UserResult();
            userResult.setStatus("ok");
            //获取账户权限
            userResult.setCurrentAuthority("admin");
            userResult.setType("account");
            return userResult;
        }
        return null;
    }
}
