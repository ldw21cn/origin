package net.wanho.controller;


import com.battcn.boot.request.annotation.*;
import com.battcn.boot.request.configuration.redis.limit.RedisLimit;
import net.wanho.model.TmDto;
import net.wanho.service.TmenuServiceI;
import net.wanho.utils.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/9 16:41
 * @Version 1.0
 */
@RestController
@RequestMapping
public class MenuController {

    @Autowired
    private TmenuServiceI tmenuService;


    @RedisLimit
    @GetMapping("/getMenu")
    public JsonResult getMenu() {
        List<TmDto> tmenuDtos = tmenuService.selectTmenus();
        JsonResult jsonResult = new JsonResult();
        jsonResult.setData(tmenuDtos);
        return jsonResult;
    }

}
