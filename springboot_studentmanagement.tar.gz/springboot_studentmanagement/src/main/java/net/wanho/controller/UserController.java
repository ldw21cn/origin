package net.wanho.controller;


import com.github.pagehelper.PageInfo;
import net.wanho.model.Student;
import net.wanho.model.User;
import net.wanho.service.StudentServiceI;
import net.wanho.service.UserServiceI;
import net.wanho.utils.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/1 16:11
 * @Version 1.0
 */
@Controller
@RequestMapping
public class UserController {

    @Autowired
    private UserServiceI userService;

    @Autowired
    private StudentServiceI studentService;

    @RequestMapping("/getCurrentUser")
    @ResponseBody
    public String getCurrentUser() {
        List<User> userList = userService.getCurrentUser();
        return userList+"";
    }


    @RequestMapping(value = "/users",method = RequestMethod.GET)
    @ResponseBody
    public JsonResult getUser(Integer _page, Integer _limit, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin", "*");
        PageInfo<Student> pageInfo = studentService.getAllStudents(_page, _limit);
        JsonResult jsonResult = new JsonResult();
        jsonResult.setData(pageInfo.getList());
        jsonResult.setTotal(pageInfo.getPages());
        return jsonResult;
    }

    @RequestMapping(value = "/users/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public JsonResult delUser(@PathVariable("id") String id) {
        return null;
    }

    @RequestMapping(value = "/users/{id}",method = RequestMethod.PATCH)
    @ResponseBody
    public JsonResult updateUser(@PathVariable("id") String id) {
        return null;
    }

    @RequestMapping(value = "/users", method = RequestMethod.POST)
    public JsonResult createUser() {
        return null;
    }

}
