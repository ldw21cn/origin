package net.wanho.model;


import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/10 14:46
 * @Version 1.0
 */
public class TmDto extends TMenu{

    private List<TMenu> routes;

    public List<TMenu> getRoutes() {
        return routes;
    }

    public void setRoutes(List<TMenu> routes) {
        this.routes = routes;
    }

    @Override
    public String toString() {
        return "TmDto{" +
                "routes=" + routes +
                "} " + super.toString();
    }
}
