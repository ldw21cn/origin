package net.wanho.model;


import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/5 15:17
 * @Version 1.0
 */
public class Test {


    /**
     * success : null
     * code : null
     * message : null
     * list : [{"id":24,"name":"测试 xxx","title":"这是一个任务描述","owner":"曲贡","desc":"777777777","callNo":1460000,"status":"2","updatedAt":1554437076000,"createdAt":1554437076000},{"id":25,"name":"测试 xxx","title":"这是一个任务描述","owner":"曲贡","desc":"llllllllll","callNo":1460000,"status":"2","updatedAt":1554437192000,"createdAt":1554437192000},{"id":26,"name":"测试 xxx","title":"这是一个任务描述","owner":"曲贡","desc":"jhjhkhhkhsdf","callNo":1460000,"status":"2","updatedAt":1554437287000,"createdAt":1554437287000},{"id":27,"name":"测试 xxx","title":"这是一个任务描述","owner":"曲贡","desc":"11111111111","callNo":1460000,"status":"2","updatedAt":1554437301000,"createdAt":1554437301000},{"id":28,"name":"测试 xxx","title":"这是一个任务描述","owner":"曲贡","desc":"1111111","callNo":1460000,"status":"2","updatedAt":1554439865000,"createdAt":1554439865000},{"id":29,"name":"测试 xxx","title":"这是一个任务描述","owner":"曲贡","desc":"111111111111","callNo":1460000,"status":"2","updatedAt":1554439904000,"createdAt":1554439904000},{"id":30,"name":"测试 xxx","title":"这是一个任务描述","owner":"曲贡","desc":"嘻嘻嘻嘻嘻嘻休息休息","callNo":1460000,"status":"2","updatedAt":1554440093000,"createdAt":1554440093000},{"id":31,"name":"测试 xxx","title":"这是一个任务描述","owner":"曲贡","desc":"1嘻嘻嘻嘻嘻嘻","callNo":1460000,"status":"2","updatedAt":1554440159000,"createdAt":1554440159000}]
     * pagination : {"current":1,"pageSize":10,"total":8}
     */

    private Object success;
    private Object code;
    private Object message;
    private PaginationBean pagination;
    private List<ListBean> list;

    public Object getSuccess() {
        return success;
    }

    public void setSuccess(Object success) {
        this.success = success;
    }

    public Object getCode() {
        return code;
    }

    public void setCode(Object code) {
        this.code = code;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public PaginationBean getPagination() {
        return pagination;
    }

    public void setPagination(PaginationBean pagination) {
        this.pagination = pagination;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class PaginationBean {
        /**
         * current : 1
         * pageSize : 10
         * total : 8
         */

        private int current;
        private int pageSize;
        private int total;

        public int getCurrent() {
            return current;
        }

        public void setCurrent(int current) {
            this.current = current;
        }

        public int getPageSize() {
            return pageSize;
        }

        public void setPageSize(int pageSize) {
            this.pageSize = pageSize;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }
    }

    public static class ListBean {
        /**
         * id : 24
         * name : 测试 xxx
         * title : 这是一个任务描述
         * owner : 曲贡
         * desc : 777777777
         * callNo : 1460000
         * status : 2
         * updatedAt : 1554437076000
         * createdAt : 1554437076000
         */

        private int id;
        private String name;
        private String title;
        private String owner;
        private String desc;
        private int callNo;
        private String status;
        private long updatedAt;
        private long createdAt;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getOwner() {
            return owner;
        }

        public void setOwner(String owner) {
            this.owner = owner;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        public int getCallNo() {
            return callNo;
        }

        public void setCallNo(int callNo) {
            this.callNo = callNo;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public long getUpdatedAt() {
            return updatedAt;
        }

        public void setUpdatedAt(long updatedAt) {
            this.updatedAt = updatedAt;
        }

        public long getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(long createdAt) {
            this.createdAt = createdAt;
        }
    }
}
