package net.wanho.model;

public class TMenu {
    private Integer id;
    private String path;
    private String name;
    private String icon;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public TMenu(Integer id, String path, String name, String icon) {
        this.id = id;
        this.path = path;
        this.name = name;
        this.icon = icon;
    }

    public TMenu() {
    }

    @Override
    public String toString() {
        return "TMenu{" +
                "id=" + id +
                ", path='" + path + '\'' +
                ", name='" + name + '\'' +
                ", icon='" + icon + '\'' +
                '}';
    }
}