package net.wanho.model;


import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import org.hibernate.validator.constraints.NotEmpty;

import java.io.Serializable;
import java.util.Date;

/**
 * @Author lvdawei
 * @Date 2019/4/2 09:37
 * @Version 1.0
 */
public class Rule implements Serializable {

    private Integer id;

    @NotEmpty
    private String name;

    @NotEmpty
    private String title;
    private String owner;
    private String desc;
    private Integer callNo;
    private String status;

    private Date updatedAt;
    private Date createdAt;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Integer getCallNo() {
        return callNo;
    }

    public void setCallNo(Integer callNo) {
        this.callNo = callNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        Date date = DateUtil.date(Long.parseLong(updatedAt));
        this.updatedAt = date;
    }


    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Rule() {
    }

    public Rule(Integer id, String name, String title, String owner, String desc, Integer callNo, String status, Date updatedAt, Date createdAt) {
        this.id = id;
        this.name = name;
        this.title = title;
        this.owner = owner;
        this.desc = desc;
        this.callNo = callNo;
        this.status = status;
        this.updatedAt = updatedAt;
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "Rule{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", title='" + title + '\'' +
                ", owner='" + owner + '\'' +
                ", desc='" + desc + '\'' +
                ", callNo=" + callNo +
                ", status='" + status + '\'' +
                ", updatedAt=" + updatedAt +
                ", createdAt=" + createdAt +
                '}';
    }
}
