package net.wanho.model;


import lombok.Data;

import java.io.Serializable;

/**
 * @Author lvdawei
 * @Date 2019/4/1 16:02
 * @Version 1.0
 */
@Data
public class User implements Serializable {

    private Integer id;
    private String username;
    private String password;

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
