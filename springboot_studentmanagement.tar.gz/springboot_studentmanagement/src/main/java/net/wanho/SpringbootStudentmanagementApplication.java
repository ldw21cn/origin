package net.wanho;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;


@SpringBootApplication
@EnableTransactionManagement
@MapperScan("net.wanho.mapper")
@EnableWebMvc
@ImportResource(locations = "classpath:redis/applicationContext-redis.xml")
public class SpringbootStudentmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootStudentmanagementApplication.class, args);
	}

}

