package net.wanho.utils;


import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @Author lvdawei
 * @Date 2019/4/16 17:31
 * @Version 1.0
 */
public class ThreadPool {

    private static ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
            32,
            10000,
            60L,
            TimeUnit.SECONDS,
            new LinkedBlockingDeque<Runnable>(1000)
    );


    public static void main(String[] args) {

        for (int i = 1; i < 10; i++) {
            threadPoolExecutor.execute(
                    new Runnable() {
                        @Override
                        public void run() {
                            long start = System.currentTimeMillis();
                            for (int i = 1; i < 10; i++) {
                                System.out.println(Thread.currentThread().getName()+",i=" + i);
                            }
                            long stop = System.currentTimeMillis();
                            System.out.println("花费时间(毫秒)：" + (stop - start));
                        }
                    }
            );
        }
    }

}
