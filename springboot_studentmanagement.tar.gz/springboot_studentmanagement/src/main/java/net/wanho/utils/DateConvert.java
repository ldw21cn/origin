package net.wanho.utils;


import cn.hutool.core.date.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @Author lvdawei
 * @Date 2019/4/8 14:27
 * @Version 1.0
 */
//@Component
public class DateConvert implements Converter<String, Date> {


    @Override
    public Date convert(String s) {
        if (StringUtils.isNotBlank(s)) {
            long l = Long.parseLong(s);
            return DateUtil.date(l);
        }
        return null;
    }
}