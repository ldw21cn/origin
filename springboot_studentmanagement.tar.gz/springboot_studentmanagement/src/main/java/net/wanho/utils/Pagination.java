package net.wanho.utils;


import lombok.Data;

import java.io.Serializable;

/**
 * @Author lvdawei
 * @Date 2019/4/2 22:07
 * @Version 1.0
 */
public class Pagination implements Serializable {

    private Integer current;
    private Integer pageSize;
    private Long total;

    public Integer getCurrent() {
        return current;
    }

    public void setCurrent(Integer current) {
        this.current = current;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public Pagination(Integer current, Integer pageSize, Long total) {
        this.current = current;
        this.pageSize = pageSize;
        this.total = total;
    }

    public Pagination() {
    }

    @Override
    public String toString() {
        return "Pagination{" +
                "current=" + current +
                ", pageSize=" + pageSize +
                ", total=" + total +
                '}';
    }
}
