package net.wanho.utils;

/*
 *   Create with IntelliJ IDEA
 *   User:   lvdawei
 *   Date:   2019/1/14
 *   Time:   18:55
 */


public class PageConst {

    public final static Integer pageSize=3;

}
