package net.wanho.utils;


import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/1 16:34
 * @Version 1.0
 */
public class HttpResult implements Serializable {

    private Boolean success;
    private Integer code;
    private String message;
    private List list;
    private Object pagination;

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List getList() {
        return list;
    }

    public void setList(List list) {
        this.list = list;
    }

    public Object getPagination() {
        return pagination;
    }

    public void setPagination(Object pagination) {
        this.pagination = pagination;
    }

    public HttpResult(Boolean success, Integer code, String message, List list, Object pagination) {
        this.success = success;
        this.code = code;
        this.message = message;
        this.list = list;
        this.pagination = pagination;
    }

    public HttpResult() {
    }
}
