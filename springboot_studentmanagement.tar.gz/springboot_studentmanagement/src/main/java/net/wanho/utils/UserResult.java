package net.wanho.utils;


import java.io.Serializable;

/**
 * @Author lvdawei
 * @Date 2019/4/18 20:36
 * @Version 1.0
 */
public class UserResult implements Serializable {

    private String status;

    private String type;

    private String currentAuthority;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCurrentAuthority() {
        return currentAuthority;
    }

    public void setCurrentAuthority(String currentAuthority) {
        this.currentAuthority = currentAuthority;
    }

    public UserResult() {
    }

    public UserResult(String status, String type, String currentAuthority) {
        this.status = status;
        this.type = type;
        this.currentAuthority = currentAuthority;
    }

    @Override
    public String toString() {
        return "UserResult{" +
                "status='" + status + '\'' +
                ", type='" + type + '\'' +
                ", currentAuthority='" + currentAuthority + '\'' +
                '}';
    }
}
