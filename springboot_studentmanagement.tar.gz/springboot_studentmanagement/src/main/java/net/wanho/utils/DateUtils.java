package net.wanho.utils;


import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.util.IdUtil;
import cn.hutool.log.LogFactory;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * @Author lvdawei
 * @Date 2019/4/8 11:09
 * @Version 1.0
 */
public class DateUtils {

    public  static void stringToDate() {

        String source = "1512900770";

        LocalDateTime time = LocalDateTime.ofInstant(Instant.ofEpochSecond(Long.parseLong(source)), ZoneId.systemDefault());
        System.out.println(time);

    }

    public static void timestampToDate() {
        Timestamp ts = new Timestamp(System.currentTimeMillis());
        Date date = new Date();
        try {
            date = ts;
            System.out.println(ts);
            System.out.println(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static String timeStamp2Date(String seconds,String format) {
        if(seconds == null || seconds.isEmpty() || seconds.equals("null")){
            return "";
        }
        if(format == null || format.isEmpty()){
            format = "yyyy-MM-dd HH:mm:ss";
        }
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(new Date(Long.valueOf(seconds+"000")/1000));
    }

    public static String convert(String s) {
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String time = dateFormatter.format(new Date(Long.valueOf(s + "000") / 1000));
        return time;
    }



    public static void main(String[] args) throws ParseException {



//        DateTime dateTime = DateUtil.parseDateTime("1551420362675");
        String s = DateUtil.date(1551420362675L).toString("yyyy-MM-dd");

        Date date = new Date(1551420362675L);

        DateTime parse = DateUtil.parse("2019-04-08 12:01:00");
        System.out.println(parse);

        String s1 = "1551420362675";
        long l = Long.parseLong(s1);
        DateTime date1 = DateUtil.date(l);


        System.out.println(date1);

    }

}
