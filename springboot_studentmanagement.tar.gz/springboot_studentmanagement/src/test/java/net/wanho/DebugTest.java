package net.wanho;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.SQLOutput;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * @Author lvdawei
 * @Date 2019/4/18 10:26
 * @Version 1.0
 */
@SpringBootTest
public class DebugTest {

    @Test
    public void debugTest1() {
        for (int i = 1; i < 1000; i++) {
            System.out.println(i);
        }
    }

    @Test
    public void dropFrame() {
        int i = 99;
        method1(i);
    }

    public void method1(int i) {
        System.out.println("method1: " + i);
        method2(i);
    }

    public void method2(int i) {
        i++;
        System.out.println("method2: " + i);
    }


    @Test
    public void multiThreadTest() throws InterruptedException {

        CountDownLatch latch = new CountDownLatch(5);

        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("thread1...");
                latch.countDown();
            }
        },"thread1").start();

        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("thread2...");
                latch.countDown();
            }
        },"thread2").start();

        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("thread3...");
                latch.countDown();
            }
        },"thread3").start();

//        latch.await(10, TimeUnit.SECONDS);
        latch.await();
        System.out.println("thread main...");


    }





}
