package net.wanho.configure;


import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * @Author lvdawei
 * @Date 2019/4/14 13:05
 * @Version 1.0
 */
public class CustomConfigTest {

    @InjectMocks
    private CustomConfig adminConfig = CustomConfig.getAdminConfig();

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getCustomConfig() {
        adminConfig.getMailHost();
        adminConfig.getMailPort();
    }

}
