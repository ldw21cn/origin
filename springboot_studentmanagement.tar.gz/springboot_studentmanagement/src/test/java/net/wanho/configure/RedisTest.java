package net.wanho.configure;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @Author lvdawei
 * @Date 2019/4/16 10:05
 * @Version 1.0
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class RedisTest {


    @Autowired
    @Qualifier(value = "redisTemplate1")
    private RedisTemplate redisTemplate1;

    @Test
    public void test() {

        System.out.println(redisTemplate1);
        try {
            redisTemplate1.opsForValue().set("name", "张三");
            Object name = redisTemplate1.opsForValue().get("name");
            System.out.println(name);
        } catch (Exception e) {
            e.printStackTrace();
        }



    }


}
