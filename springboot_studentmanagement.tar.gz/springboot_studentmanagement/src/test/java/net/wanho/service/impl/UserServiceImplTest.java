package net.wanho.service.impl;


import net.wanho.mapper.UserMapper;
import net.wanho.model.User;
import net.wanho.service.UserServiceI;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.validation.constraints.AssertTrue;
import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/11 22:37
 * @Version 1.0
 */
public class UserServiceImplTest {

    @InjectMocks
    private UserServiceI userService = new UserServiceImpl();

    @Mock
    private UserMapper userMapper;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void userTest() {
        List<User> currentUser = userService.getCurrentUser();
        System.out.println(currentUser);
    }

}
