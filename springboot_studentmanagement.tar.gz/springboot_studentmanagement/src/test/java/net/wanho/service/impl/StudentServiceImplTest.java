package net.wanho.service.impl;


import net.wanho.mapper.StudentMapper;
import net.wanho.model.Student;
import net.wanho.service.StudentServiceI;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;

/**
 * @Author lvdawei
 * @Date 2019/4/11 22:30
 * @Version 1.0
 */
public class StudentServiceImplTest {

    @InjectMocks
    private StudentServiceI studentService = new StudentServiceImpl();

    @Mock
    private StudentMapper studentMapper;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void studentTest() {
        studentService.delStudentById(1);
        studentService.getAllStudents(1);
        studentService.getAllStudents();
        studentService.getAllStudents(1, 10);
    }

}
