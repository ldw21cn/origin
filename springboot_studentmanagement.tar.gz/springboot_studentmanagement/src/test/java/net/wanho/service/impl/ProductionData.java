package net.wanho.service.impl;


import net.wanho.mapper.StudentMapper;
import net.wanho.model.Student;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @Author lvdawei
 * @Date 2019/4/17 09:26
 * @Version 1.0
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class ProductionData {

    @Autowired
    private StudentMapper studentMapper;

    /**
     * 多线程插入数据库1000万条数据
     */
    @Test
    public void productionData() {

        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
                100,
                1000,
                30000,
                TimeUnit.SECONDS,
                new LinkedBlockingDeque<Runnable>(1000)
        );

        for (int i = 1; i <= 100000; i++) {
            threadPoolExecutor.execute(
                    new Runnable() {
                        @Override
                        public void run() {
                            studentMapper.addStudent(new Student(null, "张xxxx", 12));
                        }
                    }
            );
        }


        threadPoolExecutor.shutdown();

    }

}
