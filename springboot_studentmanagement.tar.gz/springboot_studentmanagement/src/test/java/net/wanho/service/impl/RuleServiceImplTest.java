package net.wanho.service.impl;


import net.wanho.mapper.RuleMapper;
import net.wanho.model.Rule;
import net.wanho.service.RuleServiceI;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * @Author lvdawei
 * @Date 2019/4/11 22:19
 * @Version 1.0
 */
public class RuleServiceImplTest {

    @InjectMocks
    private RuleServiceI ruleService = new RuleServiceImpl();

    @Mock
    private RuleMapper ruleMapper;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        Rule rule = new Rule();
        rule.setId(1);
        rule.setTitle("title");


    }

    @Test
    public void getRules() {
        ruleService.updateRule(new Rule());
        ruleService.deleteRuleById("1");
        ruleService.addRule(new Rule());
        ruleService.getRules();
    }

}
